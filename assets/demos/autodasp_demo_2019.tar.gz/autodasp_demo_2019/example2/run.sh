#!/bin/bash
./streamcluster 10 20 128 1000000 200000 5000 none /tmp/output.txt 24 config.xml
#|------------------------- Application ----------------------------| |-Config-|
