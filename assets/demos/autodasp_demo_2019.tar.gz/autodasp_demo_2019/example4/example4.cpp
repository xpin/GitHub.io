/*
 * example4.cpp
 *
 * Created on: 27/02/2016
 *
 * =========================================================================
 *  Copyright (C) 2015-, Daniele De Sensi (d.desensi.software@gmail.com)
 *
 *  This file is part of nornir.
 *
 *  nornir is free software: you can redistribute it and/or
 *  modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.

 *  nornir is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with nornir.
 *  If not, see <http://www.gnu.org/licenses/>.
 *
 * =========================================================================
 */

/**
 * Basic test for the nornir accelerator.
 */

#include <vector>
#include <iostream>
#include <fstream>
#include <nornir/nornir.hpp>

#define MICROSECSSLEEP 20000

class Worker: public nornir::Worker<int>{
public:
    void compute(int * task) {
        usleep(MICROSECSSLEEP);
        delete task;
    }
};

int main(int argc, char * argv[]) {
    int nworkers;
    if (argc != 3 || atoi(argv[1]) <= 0){
         std::cerr << "use: "
                   << argv[0]
                   << " nworkers config\n" << std::endl;
         return -1;
    }
    nworkers = atoi(argv[1]);

    nornir::Parameters p(argv[2]);
    nornir::FarmAccelerator<int> farm(&p);
    for(size_t i = 0; i < (size_t) nworkers; i++){
        farm.addWorker(new Worker);
    }
    farm.start();

    int i = 0;
    while(true){
        farm.offload(new int(i));
        i++;
    }

    farm.shutdown();
    farm.wait();
    return 0;
}

