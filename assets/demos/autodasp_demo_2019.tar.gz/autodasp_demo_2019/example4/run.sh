#!/bin/bash
./example4 24 config.xml

