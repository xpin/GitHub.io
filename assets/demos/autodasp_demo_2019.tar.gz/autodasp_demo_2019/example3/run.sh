#!/bin/bash
# Generate input if it does not exist
INPUT=in_10M.txt
if [ ! -f "$INPUT" ]; then
    echo "$INPUT does not exist, creating..."
    ./inputgen 10000000 ${INPUT}
fi
nornir_openmp   "./blackscholes 24 ${INPUT} prices.txt" /disc1/homes/desensi/autodasp_demo_2019/example3/config.xml
#|-Nornir App-| |----- Application to be executed ------| |-Config-|
