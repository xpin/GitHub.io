#!/bin/bash
watch -n 1 "cat stats.csv | (echo -e NumCores Frequency Throughput Watts; tail -n 1 && tr '\t' ' ') | cut -f 3,5,8,13 | column -t"
